JSONObject
==========

JSON wrapper for boost property tree.
Easy to use JSON library based on the API of Java JSON.org library (http://www.json.org/java/index.html).

The main focus of the library is to be easy to use and use the less amount of dependencies possible.
This library only requires boost property tree, boost reges and boos thread to be used.
