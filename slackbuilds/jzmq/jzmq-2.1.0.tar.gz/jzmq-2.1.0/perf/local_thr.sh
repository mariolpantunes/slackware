#!/bin/sh
java -classpath "../src/zmq.jar:zmq-perf.jar" local_thr $@